---
title: "My Show"
output: "show.mp3"
normalization: -16 LUFS

trim_silence: true
trim_threshold: 1%

crossfade:
  voice_to_music: 0.2
  music_to_voice: 0.2
  voice_to_voice: 0.2
  music_to_music: 0.2
---

Welcome to this show!

[audio](./assets/jingle.mp3)

# Introduction

This is your first segment to record.

[audio](./assets/music.mp3)

# Conclusion

Thank you for listening!

[audio](./assets/jingle.mp3)
